using UnityEngine;

public class CatSpawner : MonoBehaviour
{
    GameObject cat;

    float timeSinceLast = 0.0f;
    const float timeBetween = 0.5f;
    const float catSpeed = 4.0f;

    void Start() {
        cat = Resources.Load<GameObject>("Cat");
    }

    void Update()
    {
        timeSinceLast += Time.deltaTime;

        if (timeSinceLast > timeBetween) {
            timeSinceLast = 0.0f;
            SpawnCat();
        }
    }

    void SpawnCat() {
        Instantiate(cat,
            new Vector3(10, Random.Range(-40, 40) * 0.1f, 0),
            Quaternion.identity)
        .GetComponent<Cat>()
        .speed = catSpeed;
    }
}
