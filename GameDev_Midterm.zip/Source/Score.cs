using TMPro;
using UnityEngine;

public class Score : MonoBehaviour {

    TextMeshProUGUI textObject;
    int score = 0;
    public AudioSource pickupNoise;

    void Start()  {
        textObject = transform.GetComponent<TextMeshProUGUI>();
    }

    void Update() {
        textObject.text = "Points: " + score;                  
    }
    
    public void AddPoint() {
        score++;
        pickupNoise.Play();
    }
}
