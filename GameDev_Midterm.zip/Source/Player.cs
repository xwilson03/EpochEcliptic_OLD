using UnityEngine;

public class Player : MonoBehaviour
{
    Rigidbody2D rb;
    const float speed = 2.5f;

    public void Start () {
        rb = transform.GetComponent<Rigidbody2D>();
        rb.gravityScale = 0;
    }

    public void Move(Vector2 desired) {
        rb.velocity = desired * speed;
    }
}
