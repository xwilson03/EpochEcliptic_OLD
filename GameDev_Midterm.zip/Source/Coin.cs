using UnityEngine;

public class Coin : MonoBehaviour
{
    public Score score;
    public float speed = 0;

    public void Update() {
        transform.position -= new Vector3(speed * Time.deltaTime, 0, 0);
        if (transform.position.x < -9.0f) Destroy(gameObject);
    }

    void OnTriggerEnter2D() {
        score.AddPoint();
        Destroy(gameObject);
    }
}
