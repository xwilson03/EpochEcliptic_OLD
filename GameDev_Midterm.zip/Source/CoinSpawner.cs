using UnityEngine;

public class CoinSpawner : MonoBehaviour
{
    [SerializeField] GameObject coin;
    [SerializeField] Score score;

    float timeSinceLast = 0.0f;
    const float timeBetween = 1.0f;
    const float coinSpeed = 4.0f;

    void Update()
    {
        timeSinceLast += Time.deltaTime;

        if (timeSinceLast > timeBetween) {
            timeSinceLast = 0.0f;
            SpawnCoin();
        }
    }

    void SpawnCoin() {

        Coin newCoin = 
            Instantiate(coin,
                new Vector3(9, Random.Range(-40, 40) * 0.1f, 0),
                Quaternion.identity)
            .GetComponent<Coin>();

        newCoin.speed = coinSpeed;
        newCoin.score = score;
    }
}
