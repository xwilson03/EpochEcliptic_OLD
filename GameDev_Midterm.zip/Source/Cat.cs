using UnityEngine;
using UnityEngine.SceneManagement;

public class Cat : MonoBehaviour
{
    public float speed = 0;

    public void Update() {
        transform.position -= new Vector3(speed * Time.deltaTime, 0, 0);
        if (transform.position.x < -10) Destroy(gameObject);
    }

    void OnTriggerEnter2D() {
        SceneManager.LoadScene("Menu");
    }
}
