using UnityEngine;
using UnityEngine.SceneManagement;

public class InputController : MonoBehaviour
{
    [SerializeField] Player player;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape)) SceneManager.LoadScene("Menu");

        Vector2 desired = new (0, 0);

        if (Input.GetKey(KeyCode.W)) desired += Vector2.up;
        if (Input.GetKey(KeyCode.S)) desired += Vector2.down;

        desired.Normalize();
        player.Move(desired);
    }
}
